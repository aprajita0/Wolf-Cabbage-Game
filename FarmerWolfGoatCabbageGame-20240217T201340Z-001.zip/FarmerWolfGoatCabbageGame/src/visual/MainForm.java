package visual;

import java.awt.EventQueue;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JTabbedPane;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class MainForm extends JFrame {
	
	private JLabel draggedLabel; // To keep track of the currently dragged label
    private int xOffset, yOffset;
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    
    private static boolean isGameStarted = false;

    // Add JLabels for the goat, cabbage, and wolf
    private JLabel goatLabel;
    private JLabel cabbageLabel;
    private JLabel wolfLabel;
    private JTextField txtEnterName;
    private JLabel boatLabel;
    private Box horizontalBox;
    private Box RiversideB_Box;
    private Box RiversideA_Box;
    private boolean isGoatInB = false;
    private boolean isCabbageInB = false;
    private boolean isWolfInB = false;
    private boolean isFarmerInB = false;
    private JLabel lblNameDisplay;
    private JLabel lblNewLabel;
    private JLabel lblSideB;
    private static final int Y_COORD_GOAT = 80;   // Example y-coordinate for the goat
    private static final int Y_COORD_CABBAGE = 174; // Example y-coordinate for the cabbage
    private static final int Y_COORD_WOLF = 270;  // Example y-coordinate for the wolf
 
    /**
     * Launch the application.
     */
    
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    MainForm frame = new MainForm();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public MainForm() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(MainForm.class.getResource("/resources/game_icon.png")));
        setTitle("Farmer Wolf Goat Game");
        setBackground(new Color(255, 255, 255));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 200, 1007, 627);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(225, 233, 253));
        contentPane.setBorder(null);
        
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Initialize and add goat, cabbage, and wolf labels
        initializeGameElements();
 
        // Set up the initial positions of boat, goat, cabbage, and wolf
        updateGameElementPositions();

        
        horizontalBox = Box.createHorizontalBox();
        horizontalBox.setBorder(new LineBorder(new Color(0, 0, 0), 2));
        horizontalBox.setBounds(189, 236, 552, 133);
        contentPane.add(horizontalBox);
        
        // Correctly initialize class fields without re-declaration
        RiversideB_Box = Box.createVerticalBox();
        RiversideB_Box.setBorder(new LineBorder(new Color(0, 0, 0), 2));
        RiversideB_Box.setBackground(new Color(225, 233, 253));
        RiversideB_Box.setBounds(761, 80, 201, 289);
        contentPane.add(RiversideB_Box);
        
        RiversideA_Box = Box.createVerticalBox();
        RiversideA_Box.setBorder(new LineBorder(new Color(0, 0, 0), 2));
        RiversideA_Box.setBounds(37, 71, 142, 314);
        contentPane.add(RiversideA_Box); 
        
        lblNewLabel = new JLabel("Side A");
        lblNewLabel.setFont(new Font("Comic Sans MS", Font.PLAIN, 18));
        lblNewLabel.setBounds(70, 46, 72, 13);
        contentPane.add(lblNewLabel);
        
        lblSideB = new JLabel("Side B");
        lblSideB.setFont(new Font("Comic Sans MS", Font.PLAIN, 18));
        lblSideB.setBounds(818, 56, 93, 13);
        contentPane.add(lblSideB);
    }
    
    


    private void resetGame() {
        isGameStarted = false; // Reset the game state
        isGoatInB = false;
        isCabbageInB = false;
        isWolfInB = false;
        
        
        // Reset the positions of goat, cabbage, wolf, boat, and farmer labels
        updateGameElementPositions();
        
        // Clear the entered name and display label
        txtEnterName.setText("Enter User Name");
        contentPane.remove(lblNameDisplay);
        contentPane.revalidate();
        contentPane.repaint();
    }

 
    

    // Method to initialize goat, cabbage, and wolf labels
    private void initializeGameElements() {
        goatLabel = new JLabel();
        goatLabel.setBackground(new Color(225, 233, 253));
        goatLabel.setFont(new Font("Georgia", Font.BOLD, 18));
        goatLabel.setLabelFor(this);
        goatLabel.setText("Goat");
        cabbageLabel = new JLabel();
        cabbageLabel.setBackground(new Color(225, 233, 253));
        cabbageLabel.setFont(new Font("Georgia", Font.BOLD, 18));
        cabbageLabel.setText("Cabbage");
        wolfLabel = new JLabel();
        wolfLabel.setBackground(new Color(225, 233, 253));
        wolfLabel.setFont(new Font("Georgia", Font.BOLD, 18));
        wolfLabel.setText("Wolf");
        boatLabel = new JLabel();
        boatLabel.setFont(new Font("Georgia", Font.BOLD, 18));
        boatLabel.setText("Boat");


        contentPane.add(boatLabel);
        contentPane.add(goatLabel);
        contentPane.add(cabbageLabel);
        contentPane.add(wolfLabel);
         
        boatLabel.addMouseListener(new MouseAdapter() {
            @Override
            
            public void mouseClicked(MouseEvent e) {
                moveBoat();
                if (isFarmerInB) {
                	isFarmerInB = false;
                	
                	CheckForLose();
                }
                else {
                	isFarmerInB = true;
                	CheckForLose();
                	
                }
            }
        });
        
        goatLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                moveLabelToOtherSide(goatLabel);
            }
        });
        wolfLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                moveLabelToOtherSide(wolfLabel);
            }
        });
        cabbageLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                moveLabelToOtherSide(cabbageLabel);
            }
        });
        updateGameElementPositions();


        // Example for the goatLabel mouse listener
     
        
        JButton startButton = new JButton("Start");
        startButton.setBackground(new Color(128, 255, 128));
        startButton.setBounds(70, 396, 101, 26);
        contentPane.add(startButton);
        startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Update the game state when the start button is pressed
                isGameStarted = true;
   
                JTextArea textArea = new JTextArea("To play the game, click on the goat, cabbage, wolf, farmer!!");
                textArea.setFont(new Font("Georgia", Font.BOLD, 18));
                textArea.setEditable(false);
                textArea.setWrapStyleWord(true);
                textArea.setLineWrap(true);

                // Create a JScrollPane to handle scrolling if necessary
                JScrollPane scrollPane = new JScrollPane(textArea);
                scrollPane.setPreferredSize(new Dimension(400, 150));

                // Create a JOptionPane with the JTextArea
                JOptionPane.showMessageDialog(
                		MainForm.this,
                		scrollPane,
                        "You Choose Give Up",
                        JOptionPane.INFORMATION_MESSAGE);
        }
        });
        
        //text field to save name
        txtEnterName = new JTextField();
        txtEnterName.setFont(new Font("Comic Sans MS", Font.PLAIN, 12));
        txtEnterName.setHorizontalAlignment(SwingConstants.CENTER);
        txtEnterName.setText("Enter User Name");
        txtEnterName.setBounds(366, 386, 196, 26);
        contentPane.add(txtEnterName);
        txtEnterName.setColumns(10);
        
        JButton btnSubmit = new JButton("Submit");
        btnSubmit.setBounds(572, 387, 101, 26);
        contentPane.add(btnSubmit);
        lblNameDisplay = new JLabel("Entered name will be displayed here.");

     // Add action listener to the button
        btnSubmit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the entered name from the text field
                
            	if (checkForWin()) {
                String enteredName = txtEnterName.getText();
//
                // Display the name at the bottom of the panel
                lblNameDisplay.setText("Entered name: " + enteredName);
                contentPane.add(lblNameDisplay);
                lblNameDisplay.setFont(new Font("Comic Sans MS", Font.PLAIN, 18));
                lblNameDisplay.setHorizontalAlignment(SwingConstants.CENTER);
                lblNameDisplay.setBounds(400, 500, 300, 50);
            } }
        });

        // Create a panel and add components to it
//        contentPane.add(lblNameDisplay, BorderLayout.SOUTH);

        ///
        
        //button
        JButton giveUpButton = new JButton("Give Up :(");
        giveUpButton.setBackground(new Color(220, 199, 217));
        giveUpButton.setBounds(818, 396, 101, 26);
        contentPane.add(giveUpButton);
        
        giveUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

             // Create a JTextArea with your long message
                JTextArea textArea = new JTextArea("You gave up :( This is the solution: First move the goat to side B. Then move the cabbage to side B. "
                		+ "Then take goat from side B to side A. Then take wolf to side B. Lastly take goat to side B "
                		+ "Press start to try again.");
                textArea.setFont(new Font("Georgia", Font.BOLD, 18));
                textArea.setEditable(false);
                textArea.setWrapStyleWord(true);
                textArea.setLineWrap(true);

                // Create a JScrollPane to handle scrolling if necessary
                JScrollPane scrollPane = new JScrollPane(textArea);
                scrollPane.setPreferredSize(new Dimension(400, 150));

                // Create a JOptionPane with the JTextArea
                JOptionPane.showMessageDialog(
                		MainForm.this,
                		scrollPane,
                        "You Choose Give Up",
                        JOptionPane.INFORMATION_MESSAGE);
                resetGame();

                // Additional actions you may want to perform after giving up
            
            }
        });

        
        JLabel lblNewLabel_1 = new JLabel("Hall of Fame (Win the game to be entered in the hall of fame) ");
        lblNewLabel_1.setFont(new Font("Georgia", Font.BOLD, 18));
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
        lblNewLabel_1.setBounds(27, 433, 643, 50);
        contentPane.add(lblNewLabel_1);
    }

    private void moveBoat() {
        if (isGameStarted) {
	        int leftEnd = horizontalBox.getBounds().x;
	        int rightEnd = horizontalBox.getBounds().x + horizontalBox.getBounds().width - boatLabel.getWidth();
	
	        // Check the current position of the boat and move it to the opposite end
	        if (boatLabel.getBounds().x <= leftEnd) {
	            boatLabel.setBounds(rightEnd, boatLabel.getBounds().y, boatLabel.getWidth(), boatLabel.getHeight());
	          
	        } 
	        
	        else {
	            boatLabel.setBounds(leftEnd, boatLabel.getBounds().y, boatLabel.getWidth(), boatLabel.getHeight());
	            
	        }
        }
        // Repaint the panel to reflect the change
        contentPane.revalidate();
        contentPane.repaint();
    }
  
    // Helper method to move labels
    private void moveLabelToOtherSide(JLabel label) {
    	if (isGameStarted) {
	    	Rectangle riversideABounds = RiversideA_Box.getBounds();
	        Rectangle riversideBBounds = RiversideB_Box.getBounds();
	        int yCoord;
	
	        // Determine the y-coordinate based on the label
	        if (label == goatLabel) {
	            yCoord = Y_COORD_GOAT;
	        } else if (label == cabbageLabel) {
	            yCoord = Y_COORD_CABBAGE;
	        } else { // Assuming label is wolfLabel
	            yCoord = Y_COORD_WOLF;
	        }
	
	        // Check if the label is currently on Riverside A
	        if (label.getBounds().intersects(riversideABounds)) {
	            // Move to Riverside B
	        	moveBoat();
	        	isFarmerInB = true; 
	            label.setBounds(
	                riversideBBounds.x + (riversideBBounds.width - label.getWidth()) / 2,
	                yCoord,
	                label.getWidth(),
	                label.getHeight()
	            );
	           
	        } else {
	            // Move to Riverside A
	        	
	            label.setBounds(
	                riversideABounds.x + (riversideABounds.width - label.getWidth()) / 2,
	                yCoord,
	                label.getWidth(),
	                label.getHeight()
	            );
	            moveBoat();
	            isFarmerInB = false;
	        }
	        if (label == goatLabel) {
	            isGoatInB = label.getBounds().intersects(RiversideB_Box.getBounds());
	        } else if (label == cabbageLabel) {
	            isCabbageInB = label.getBounds().intersects(RiversideB_Box.getBounds());
	        } else if (label == wolfLabel) {
	            isWolfInB = label.getBounds().intersects(RiversideB_Box.getBounds());
	        }
	        
	        contentPane.revalidate();
	        contentPane.repaint();
	        // Check if the game is won after moving the item
	        CheckForLose();
	        checkForWin();
	    }
    }
        // Repaint the panel to reflect the change

    
    private boolean checkForWin() {
    if (isGoatInB && isCabbageInB && isWolfInB) {
        // Player wins the game
        JOptionPane.showMessageDialog(this, "Congratulations! You have won the game!", "Game Won", JOptionPane.INFORMATION_MESSAGE);
        return true;
        }
    else {
    	return false;
    }
    }
    
    private void CheckForLose() {
        if (isGoatInB && isCabbageInB && (isFarmerInB == false)) {
            // Player wins the game
            JOptionPane.showMessageDialog(this, "You lost the game, the goat ate the cabbage!", "Game Lost", JOptionPane.INFORMATION_MESSAGE);
            // Reset game or perform any other action as needed
            resetGame();
            }
        if (isGoatInB && isWolfInB && (isFarmerInB == false)) {
            // Player wins the game
            JOptionPane.showMessageDialog(this, "You lost the game, the wolf ate the goat!", "Game Lost", JOptionPane.INFORMATION_MESSAGE);
            // Reset game or perform any other action as needed
            resetGame();
            }
        if (isFarmerInB && (isWolfInB == false) && (isGoatInB == false)) {
            // Player wins the game
            JOptionPane.showMessageDialog(this, "You lost the game, The wolf ate the goat!", "Game Lost", JOptionPane.INFORMATION_MESSAGE);
            // Reset game or perform any other action as needed
            resetGame();
            }
        if (isFarmerInB && (isCabbageInB == false) && (isGoatInB == false)) {
            // Player wins the game
            JOptionPane.showMessageDialog(this, "You lost the game, The wolf ate the goat!", "Game Lost", JOptionPane.INFORMATION_MESSAGE);
            // Reset game or perform any other action as needed
            resetGame();
            }
       
        
        }

    // Method to update the positions of goat, cabbage, and wolf labels
    private void updateGameElementPositions() {
        // Set the initial positions for goat, cabbage, and wolf
        goatLabel.setBounds(70, 80, 80, 80);
        cabbageLabel.setBounds(71, 174, 79, 65);
        wolfLabel.setBounds(70, 270, 90, 100);

        // Set the initial positions for boat, farmer, and riversides
        boatLabel.setBounds(188, 245, 142, 100);

        ImageIcon goatIcon = new ImageIcon(getClass().getResource("/resources/goat.jpeg"));
        ImageIcon cabbageIcon = new ImageIcon(getClass().getResource("/resources/cabbage.jpeg"));
        ImageIcon wolfIcon = new ImageIcon(getClass().getResource("/resources/wolf.jpeg"));
        ImageIcon boatIcon = new ImageIcon(getClass().getResource("/resources/boatFarmer.jpg"));
       
        Image goatImage = goatIcon.getImage().getScaledInstance(goatLabel.getWidth(), goatLabel.getHeight(), Image.SCALE_SMOOTH);
        Image cabbageImage = cabbageIcon.getImage().getScaledInstance(cabbageLabel.getWidth(), cabbageLabel.getHeight(), Image.SCALE_SMOOTH);
        Image wolfImage = wolfIcon.getImage().getScaledInstance(wolfLabel.getWidth(), wolfLabel.getHeight(), Image.SCALE_SMOOTH);
        Image boatImage = boatIcon.getImage().getScaledInstance(boatLabel.getWidth(),boatLabel.getHeight(),Image.SCALE_SMOOTH);
        
        
      
        goatIcon = new ImageIcon(goatImage);
        cabbageIcon = new ImageIcon(cabbageImage);
        wolfIcon = new ImageIcon(wolfImage);
        boatIcon = new ImageIcon(boatImage);

        goatLabel.setIcon(goatIcon);
        cabbageLabel.setIcon(cabbageIcon);
        wolfLabel.setIcon(wolfIcon);
        boatLabel.setIcon(boatIcon);
     
        // Set the text to be blank as you're using images instead of text
        goatLabel.setText("");
        cabbageLabel.setText("");
        wolfLabel.setText("");
        boatLabel.setText("");

    }
}
