/**
 * 
 */
/**
 * 
 */
module FarmerWolfGoatCabbageGame {
	requires java.desktop;
}